import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class QuizEngineService {
  constructor() {}

  private scoreSubject = new BehaviorSubject<number>(0);
  score$ = this.scoreSubject.asObservable();

  // New flag to mark quiz completion
  private quizCompleted = false;
  private totalQuestions: number = 0;

  incrementScore(): void {
    this.scoreSubject.next(this.scoreSubject.value + 1);
  }

  getScore(): number {
    return this.scoreSubject.value;
  }

  markQuizCompleted(): void {
    this.quizCompleted = true;
  }

  isQuizCompleted(): boolean {
    return this.quizCompleted;
  }

  setTotalQuestions(total: number): void {
    this.totalQuestions = total;
  }
  getTotalQuestions(): number {
    return this.totalQuestions;
  }
}
