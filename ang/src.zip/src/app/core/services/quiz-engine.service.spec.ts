import { TestBed } from '@angular/core/testing';

import { QuizEngineService } from './quiz-engine.service';

describe('QuizEngineService', () => {
  let service: QuizEngineService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(QuizEngineService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
