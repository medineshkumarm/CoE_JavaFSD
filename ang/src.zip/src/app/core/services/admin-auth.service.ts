import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AdminAuthService {
  constructor() {}
  private loggedInSubject = new BehaviorSubject<boolean>(false);
  adminLoggedIn$ = this.loggedInSubject.asObservable();

  // For synchronous check
  isLoggedIn = false;

  login(): void {
    this.isLoggedIn = true;
    this.loggedInSubject.next(true);
  }

  logout(): void {
    this.isLoggedIn = false;
    this.loggedInSubject.next(false);
  }
}
