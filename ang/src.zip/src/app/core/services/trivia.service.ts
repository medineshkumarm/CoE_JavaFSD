import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TriviaService {


  private apiUrl = 'http://localhost:4500/questions';

  constructor(private http: HttpClient) { }

  getQuestions(difficulty: string): Observable<any[]> {
    // Assuming your JSON Server supports filtering via query params (e.g., ?difficulty=easy)
    return this.http.get<any[]>(`${this.apiUrl}?difficulty=${difficulty}`);
  }

  addQuestion(question: any): Observable<any> {
    // Replace the URL with your API endpoint
    return this.http.post('http://localhost:4500/questions', question);
  }
  
}
