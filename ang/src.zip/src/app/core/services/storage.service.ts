import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class StorageService {
  constructor() {}

  private storageKey = 'quizProgress';

  saveProgress(data: any): void {
    localStorage.setItem(this.storageKey, JSON.stringify(data));
  }

  getProgress(): any {
    return JSON.parse(localStorage.getItem(this.storageKey) || '{}');
  }
}
