import { CanActivateFn } from '@angular/router';
import { Router } from '@angular/router';
import { inject } from '@angular/core';
import { QuizEngineService } from '../services/quiz-engine.service';

export const resultsGuard: CanActivateFn = (route, state) => {
  const quizEngineService = inject(QuizEngineService);
  const router = inject(Router);

  if (!quizEngineService.isQuizCompleted()) {
    console.log('Quiz not completed, redirecting to home.');
    router.navigate(['/']);
    return false;
  }

  
  return true;
};