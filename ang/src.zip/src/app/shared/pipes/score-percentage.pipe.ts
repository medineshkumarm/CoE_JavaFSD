import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'scorePercentage',
})
export class ScorePercentagePipe implements PipeTransform {
  transform(score: number, total: number): string {
    const percentage = (score / total) * 100;
    return percentage.toFixed(0) + '%';
  }
}
