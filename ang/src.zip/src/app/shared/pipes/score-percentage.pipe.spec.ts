import { ScorePercentagePipe } from './score-percentage.pipe';

describe('ScorePercentagePipe', () => {
  it('create an instance', () => {
    const pipe = new ScorePercentagePipe();
    expect(pipe).toBeTruthy();
  });
});
