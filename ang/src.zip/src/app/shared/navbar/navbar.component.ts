import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AdminAuthService } from '../../core/services/admin-auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css',
})
export class NavbarComponent {
  isAdminLoggedIn = false;
  adminUsername = '';
  adminPassword = '';

  constructor(
    private router: Router,
    private adminAuthService: AdminAuthService
  ) {
    // Subscribe to admin login state changes
    this.adminAuthService.adminLoggedIn$.subscribe((state) => {
      this.isAdminLoggedIn = state;
    });
  }

  login(): void {
    // Example hardcoded authentication
    if (this.adminUsername === 'admin' && this.adminPassword === 'admin123') {
      this.adminAuthService.login();

      //store in localstorage

      // Store admin credentials in localStorage
      localStorage.setItem('adminUsername', this.adminUsername);
      localStorage.setItem('isAdminLoggedIn', 'true');

      alert('Admin logged in successfully.');
      this.router.navigate(['/admin']);
    } else {
      alert('Invalid credentials. Please try again.');
    }
  }

  logout(): void {
    this.adminAuthService.logout();
    this.adminUsername = '';
    this.adminPassword = '';

    // Clear admin data from localStorage
    localStorage.removeItem('adminUsername');
    localStorage.removeItem('isAdminLoggedIn');
    alert('Logged out successfully.');
    this.router.navigate(['/']);
  }
}
