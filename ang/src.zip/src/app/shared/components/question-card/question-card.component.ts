import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-question-card',
  templateUrl: './question-card.component.html',
  styleUrl: './question-card.component.css'
})
export class QuestionCardComponent {
  @Input() question: any;
  @Output() answerSelected = new EventEmitter<{ questionId: number, selected: string, correct: boolean }>();

  answered = false; // Flag to prevent multiple clicks


  select(option: string): void {
    if (this.answered) {
      return; // Ignore further clicks once answered
    }
    this.answered = true;

    const isCorrect = option === this.question.correctAnswer;
    this.answerSelected.emit({ questionId: this.question.id, selected: option, correct: isCorrect });
  }
}
