import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { QuizSetupComponent } from './pages/quiz-setup/quiz-setup.component';
import { QuizContainerComponent } from './pages/quiz/quiz-container/quiz-container.component';
import { ResultsComponent } from './pages/results/results.component';
import { QuestionCardComponent } from './shared/components/question-card/question-card.component';
import { HomeComponent } from './pages/home/home.component';
import { AnswerHighlightDirective } from './directives/answer-highlight.directive';
import { ScorePercentagePipe } from './shared/pipes/score-percentage.pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AdminPanelComponent } from './admin/admin-panel/admin-panel.component';
import { NavbarComponent } from './shared/navbar/navbar.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    QuizSetupComponent,
    QuizContainerComponent,
    ResultsComponent,
    QuestionCardComponent,
    AnswerHighlightDirective,
    ScorePercentagePipe,
    AdminPanelComponent,
    NavbarComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
