import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TriviaService } from '../../../core/services/trivia.service';
import { QuizEngineService } from '../../../core/services/quiz-engine.service';
 
interface Question {
  id: string;
  text: string;
  options: string[];
  correctAnswer: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

@Component({
  selector: 'app-quiz-container',
  templateUrl: './quiz-container.component.html',
  styleUrl: './quiz-container.component.css',
})
export class QuizContainerComponent {
  questions: Question[] = [];
  score = 0;
  difficulty: string = '';
  answeredCount = 0; // Track number of answered questions

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private triviaService: TriviaService,
    private quizEngineService: QuizEngineService
  ) {}

  ngOnInit(): void {
    this.difficulty =
      this.route.snapshot.paramMap.get('difficulty') || 'medium';
    // Fetch questions based on difficulty
    this.triviaService.getQuestions(this.difficulty).subscribe((data) => {
      this.questions = data;
      console.log('Questions loaded:', this.questions);
      // Set total questions count in the service
      this.quizEngineService.setTotalQuestions(this.questions.length);
    });

    
    // Subscribe to score updates
    this.quizEngineService.score$.subscribe((s) => (this.score = s));
  }

  handleAnswer(answer: {
    questionId: number;
    selected: string;
    correct: boolean;
  }): void {
    console.log('Answer received:', answer);
    if (answer.correct) {
      this.quizEngineService.incrementScore();
    }
    this.answeredCount++;
    console.log(
      'Answered Count:',
      this.answeredCount,
      'Total Questions:',
      this.questions.length
    );

    if (this.answeredCount >= this.questions.length) {
      this.quizEngineService.markQuizCompleted();
      console.log('Quiz completed, redirecting to results...');
      setTimeout(() => this.router.navigate(['/results']), 500);
    }
  }
}
