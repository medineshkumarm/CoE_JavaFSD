import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-quiz-setup',
  templateUrl: './quiz-setup.component.html',
  styleUrl: './quiz-setup.component.css'
})
export class QuizSetupComponent {

  constructor(private router: Router){}

  startQuiz(formValue: any){
    // For simplicity, we only use the difficulty for routing.
    const difficulty = formValue.difficulty;
    // Optionally, you could save category in local storage.
    this.router.navigate(['/quiz', difficulty]);
  }

}
