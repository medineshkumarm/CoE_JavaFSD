import { Component } from '@angular/core';
import { QuizEngineService } from '../../core/services/quiz-engine.service';

@Component({
  selector: 'app-results',
  templateUrl: './results.component.html',
  styleUrl: './results.component.css'
})
export class ResultsComponent {
  score = 0;
  totalQuestions = 5;  // For MVP, adjust as needed

  constructor(private quizEngineService: QuizEngineService) { }

  ngOnInit(): void {
    this.score = this.quizEngineService.getScore();
    this.totalQuestions = this.quizEngineService.getTotalQuestions();
  }
}
