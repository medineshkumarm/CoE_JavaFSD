import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { QuizSetupComponent } from './pages/quiz-setup/quiz-setup.component';
import { QuizContainerComponent } from './pages/quiz/quiz-container/quiz-container.component';
import { ResultsComponent } from './pages/results/results.component';
import { resultsGuard } from './core/guards/results.guard';
import { AdminPanelComponent } from './admin/admin-panel/admin-panel.component';
import { adminGuard } from './core/guards/admin.guard';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'setup', component: QuizSetupComponent },
  { path: 'quiz/:difficulty', component: QuizContainerComponent },
  { path: 'results', component: ResultsComponent, canActivate: [resultsGuard] },
  { path: 'admin', component: AdminPanelComponent,canActivate: [adminGuard] }  // new admin route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
