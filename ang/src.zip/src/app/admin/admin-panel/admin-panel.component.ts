import { Component } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TriviaService } from '../../core/services/trivia.service';

@Component({
  selector: 'app-admin-panel',
  templateUrl: './admin-panel.component.html',
  styleUrl: './admin-panel.component.css'
})
export class AdminPanelComponent {
  questionForm!: FormGroup;

  constructor(private fb: FormBuilder, private triviaService: TriviaService) {}

  ngOnInit(): void {
    this.questionForm = this.fb.group({
      text: ['', Validators.required],
      correctAnswer: ['', Validators.required],
      difficulty: ['easy', Validators.required],
      options: this.fb.array([
        this.fb.control('', Validators.required),
        this.fb.control('', Validators.required),
        this.fb.control('', Validators.required),
        this.fb.control('', Validators.required)
      ])
    });
  }
  
  get options() {
    return this.questionForm.get('options') as FormArray;
  }
  addQuestion() {
    if (this.questionForm.valid) {
      // You can integrate this with your service to save the new question
      this.triviaService.addQuestion(this.questionForm.value).subscribe(() => {
        alert('Question added successfully!');
        this.questionForm.reset();
      });
    }
  }
}
