import { AnswerHighlightDirective } from './answer-highlight.directive';

describe('AnswerHighlightDirective', () => {
  it('should create an instance', () => {
    const directive = new AnswerHighlightDirective();
    expect(directive).toBeTruthy();
  });
});
