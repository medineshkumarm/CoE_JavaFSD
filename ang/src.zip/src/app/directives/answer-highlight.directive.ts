import { Directive, HostBinding, Input } from '@angular/core';

@Directive({
  selector: '[appAnswerHighlight]'
})
export class AnswerHighlightDirective {

  constructor() { }

  @Input('appAnswerHighlight') isCorrect: boolean = false;

  @HostBinding('style.boxShadow') get boxShadow(): string {
    return this.isCorrect ? '0 0 15px green' : '0 0 15px red';
  }

}
