import 'package:coupxcode/app_config.dart';
import 'package:coupxcode/providers/theme_provider.dart';
import 'package:coupxcode/screens/nav_wrapper.dart';
import 'package:coupxcode/theme.dart';
import 'package:coupxcode/screens/coupon_exchange_screen.dart';
import 'package:coupxcode/screens/login_screen.dart';
import 'package:coupxcode/screens/settings_screen.dart';
import 'package:coupxcode/screens/user_profile_screen.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'firebase_options.dart';
import 'services/coupon_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(
    MultiProvider(
      providers: [
        // Coupon Service Provider
        Provider<CouponService>(
          create: (_) => CouponService(),
        ),
        // Authentication State Provider
        StreamProvider<User?>.value(
          value: FirebaseAuth.instance.authStateChanges(),
          initialData: null,
        ),

        ChangeNotifierProvider<ThemeProvider>(
          create: (_) => ThemeProvider(),
        ),
      ],
      child: CouponExchangeApp(),
    ),
  );
}


class CouponExchangeApp extends StatelessWidget {
  const CouponExchangeApp({super.key});
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: AppConfig.appName,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: themeProvider.themeMode, // Dynamic ThemeMode // Respect system theme settings

      // App Navigation
      initialRoute: '/',
      routes: {
        '/': (context) {
          final user = context.watch<User?>();
          return user != null ? BottomNavBarWrapper() : LoginScreen();
        },
        '/login': (context) => LoginScreen(),
        '/profile': (context) => ProfileScreen(),
        '/settings': (context) => SettingsScreen(),
        '/submit-coupon': (context) => CouponSubmissionScreen(),
      },

      // Error handling for unknown routes
      onUnknownRoute: (RouteSettings settings) {
        return MaterialPageRoute(
          builder: (context) => Scaffold(
            appBar: AppBar(title: Text('Error')),
            body: Center(
              child: Text('Page not found'),
            ),

          ),
        );
      },

      // Localization and Internationalization (placeholder)
      localizationsDelegates: [], // Add localization delegates
      supportedLocales: AppConfig.supportedLanguages
          .map((lang) => Locale(lang))
          .toList(),
    );
  }
}