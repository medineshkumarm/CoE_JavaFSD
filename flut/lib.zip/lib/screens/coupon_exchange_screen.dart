import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/coupon_model.dart';
import '../services/coupon_service.dart';

class CouponSubmissionScreen extends StatefulWidget {
  const CouponSubmissionScreen({super.key});

  @override
  _CouponSubmissionScreenState createState() => _CouponSubmissionScreenState();
}

class _CouponSubmissionScreenState extends State<CouponSubmissionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _vendorController = TextEditingController();
  final _discountController = TextEditingController();
  DateTime? _expirationDate;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Submit Coupon')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _titleController,
              decoration: InputDecoration(labelText: 'Coupon Title'),
              validator: (value) => value!.isEmpty ? 'Please enter a title' : null,
            ),
            TextFormField(
              controller: _descriptionController,
              decoration: InputDecoration(labelText: 'Description'),
              maxLines: 3,
              validator: (value) => value!.isEmpty ? 'Please enter a description' : null,
            ),
            TextFormField(
              controller: _vendorController,
              decoration: InputDecoration(labelText: 'Vendor Name'),
              validator: (value) => value!.isEmpty ? 'Please enter vendor name' : null,
            ),
            TextFormField(
              controller: _discountController,
              decoration: InputDecoration(labelText: 'Discount Value'),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value!.isEmpty) return 'Please enter discount value';
                if (double.tryParse(value) == null) return 'Invalid number';
                return null;
              },
            ),
            ListTile(
              title: Text('Expiration Date'),
              subtitle: Text(_expirationDate == null
                  ? 'Select Date'
                  : '${_expirationDate!.toLocal()}'.split(' ')[0]),
              onTap: _pickExpirationDate,
            ),
            ElevatedButton(
              onPressed: _submitCoupon,
              child: Text('Submit Coupon'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickExpirationDate() async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 365)),
    );

    if (pickedDate != null) {
      setState(() {
        _expirationDate = pickedDate;
      });
    }
  }

  void _submitCoupon() async {
    if (_formKey.currentState!.validate() && _expirationDate != null) {
      try {
        final coupon = Coupon(
          id: '', // Firestore will generate the ID
          title: _titleController.text,
          description: _descriptionController.text,
          vendorName: _vendorController.text,
          discountValue: double.parse(_discountController.text),
          expirationDate: _expirationDate!,
          userId: '', // You'll want to get the current user's ID
          isRedeemed: false,
        );

        await context.read<CouponService>().submitCoupon(coupon);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Coupon submitted successfully!')),
        );

        Navigator.pop(context);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to submit coupon: $e')),
        );
      }
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _vendorController.dispose();
    _discountController.dispose();
    super.dispose();
  }
}