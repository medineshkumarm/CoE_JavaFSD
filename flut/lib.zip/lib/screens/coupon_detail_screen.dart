import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/coupon_model.dart';
import '../services/coupon_service.dart';

class CouponDetailScreen extends StatelessWidget {
  final Coupon coupon;

  const CouponDetailScreen({super.key, required this.coupon});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Coupon Details'),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Coupon Title
            Text(
              coupon.title,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16),

            // Vendor Information
            _buildDetailRow('Vendor', coupon.vendorName),

            // Discount Value
            _buildDetailRow('Discount', '\$${coupon.discountValue.toStringAsFixed(2)}'),

            // Expiration Date
            _buildDetailRow(
                'Expiration Date',
                '${coupon.expirationDate.toLocal()}'.split(' ')[0]
            ),

            // Description
            SizedBox(height: 16),
            Text(
              'Description',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            Text(
              coupon.description,
              style: Theme.of(context).textTheme.bodyMedium,
            ),

            SizedBox(height: 24),

            // Redeem Button
            Center(
              child: ElevatedButton(
                onPressed: coupon.isRedeemed ? null : () => _redeemCoupon(context),
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50),
                ),
                child: Text(
                  coupon.isRedeemed ? 'Redeemed' : 'Redeem Coupon',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey[600],
            ),
          ),
          Text(
            value,
            style: TextStyle(
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  void _redeemCoupon(BuildContext context) async {
    try {
      await context.read<CouponService>().redeemCoupon(coupon.id);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Coupon redeemed successfully!'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to redeem coupon: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }
}