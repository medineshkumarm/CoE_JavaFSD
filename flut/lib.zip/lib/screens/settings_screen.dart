import 'package:coupxcode/providers/theme_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notifications = true;
  bool _darkMode = false;
  String _language = 'English';

  final List<String> _languageOptions = [
    'English',
    'Spanish',
    'French',
    'German',
    'Chinese'
  ];

  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final prefs = await SharedPreferences.getInstance();

    if (!prefs.containsKey('darkMode')) {
      await prefs.setBool('darkMode', false);
      print('Dark mode preference not found. Defaulting to light mode.');
    }
    setState(() {
      _notifications = prefs.getBool('notifications') ?? true;
      _darkMode = prefs.getBool('darkMode') ?? false;
      _language = prefs.getString('language') ?? 'English';
    });
  }

  Future<void> _savePreference(String key, dynamic value) async {
    final prefs = await SharedPreferences.getInstance();
    if (value is bool) {
      await prefs.setBool(key, value);
    } else if (value is String) {
      await prefs.setString(key, value);
    }
  }


  void _updateAppTheme(bool isDark) {
    final themeProvider = Provider.of<ThemeProvider>(context, listen: false);
    themeProvider.toggleTheme(isDark);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(isDark ? 'Dark mode enabled' : 'Light mode enabled'),
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: ListView(
        padding: EdgeInsets.all(16),
        children: [
          SwitchListTile(
            title: Text('Receive Notifications'),
            value: _notifications,
            onChanged: (bool value) {
              setState(() => _notifications = value);
              _savePreference('notifications', value);
            },
          ),
          SwitchListTile(
            title: Text('Dark Mode'),
            value: _darkMode,
            onChanged: (bool value) {
              setState(() => _darkMode = value);
              _updateAppTheme(value);
              themeProvider.toggleTheme(value);
              _savePreference('darkMode', value);
            },
          ),
          ListTile(
            title: Text('Language'),
            subtitle: Text(_language),
            trailing: Icon(Icons.chevron_right),
            onTap: _showLanguageDialog,
          ),
          ListTile(
            leading: Icon(Icons.lock_outline),
            title: Text('Change Password'),
            onTap: _changePassword,
          ),
          ListTile(
            leading: Icon(Icons.delete_forever, color: Colors.red),
            title: Text('Delete Account', style: TextStyle(color: Colors.red)),
            onTap: _confirmAccountDeletion,
          ),
        ],
      ),
    );
  }

  void _showLanguageDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Select Language'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: _languageOptions.map((lang) => RadioListTile(
            title: Text(lang),
            value: lang,
            groupValue: _language,
            onChanged: (String? value) {
              if (value != null) {
                setState(() => _language = value);
                _savePreference('language', value);
                Navigator.pop(context);
              }
            },
          )).toList(),
        ),
      ),
    );
  }

  void _changePassword() {
    // Implementation similar to the original code
  }

  void _confirmAccountDeletion() {
    // Implementation similar to the original code
  }
}

// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';
// import 'package:firebase_auth/firebase_auth.dart';
//
// class SettingsScreen extends StatefulWidget {
//   const SettingsScreen({super.key});
//
//   @override
//   _SettingsScreenState createState() => _SettingsScreenState();
// }
//
// class _SettingsScreenState extends State<SettingsScreen> {
//   // Settings variables
//   bool _notifications = true;
//   bool _darkMode = false;
//   String _language = 'English';
//
//   // Language options
//   final List<String> _languageOptions = [
//     'English',
//     'Spanish',
//     'French',
//     'German',
//     'Chinese'
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Settings'),
//       ),
//       body: ListView(
//         padding: EdgeInsets.all(16),
//         children: [
//           // Notifications Setting
//           SwitchListTile(
//             title: Text('Receive Notifications'),
//             subtitle: Text('Get updates about coupons and exchanges'),
//             value: _notifications,
//             onChanged: (bool value) {
//               setState(() {
//                 _notifications = value;
//               });
//               _saveNotificationPreference(value);
//             },
//           ),
//
//           // Dark Mode Setting
//           SwitchListTile(
//             title: Text('Dark Mode'),
//             subtitle: Text('Switch between light and dark themes'),
//             value: _darkMode,
//             onChanged: (bool value) {
//               setState(() {
//                 _darkMode = value;
//               });
//               _updateAppTheme(value);
//             },
//           ),
//
//           // Language Selection
//           ListTile(
//             title: Text('Language'),
//             subtitle: Text(_language),
//             trailing: Icon(Icons.chevron_right),
//             onTap: _showLanguageDialog,
//           ),
//
//           // Account Section
//           Padding(
//             padding: const EdgeInsets.symmetric(vertical: 16),
//             child: Text(
//               'Account',
//               style: Theme.of(context).textTheme.titleMedium,
//             ),
//           ),
//
//           // Change Password
//           ListTile(
//             leading: Icon(Icons.lock_outline),
//             title: Text('Change Password'),
//             onTap: _changePassword,
//           ),
//
//           // Delete Account
//           ListTile(
//             leading: Icon(Icons.delete_forever, color: Colors.red),
//             title: Text('Delete Account', style: TextStyle(color: Colors.red)),
//             onTap: _confirmAccountDeletion,
//           ),
//         ],
//       ),
//     );
//   }
//
//   void _saveNotificationPreference(bool value) {
//     // TODO: Implement saving notification preference
//     // This could involve updating user settings in Firestore
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text(value
//             ? 'Notifications enabled'
//             : 'Notifications disabled'
//         ),
//       ),
//     );
//   }
//
//   void _updateAppTheme(bool isDark) {
//     // TODO: Implement theme switching
//     // This would typically involve using a state management solution
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(
//         content: Text(isDark
//             ? 'Dark mode enabled'
//             : 'Light mode enabled'
//         ),
//       ),
//     );
//   }
//
//   void _showLanguageDialog() {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: Text('Select Language'),
//           content: SingleChildScrollView(
//             child: Column(
//               children: _languageOptions.map((String language) {
//                 return RadioListTile<String>(
//                   title: Text(language),
//                   value: language,
//                   groupValue: _language,
//                   onChanged: (String? value) {
//                     if (value != null) {
//                       setState(() {
//                         _language = value;
//                       });
//                       Navigator.of(context).pop();
//                     }
//                   },
//                 );
//               }).toList(),
//             ),
//           ),
//         );
//       },
//     );
//   }
//
//   void _changePassword() {
//     // Implement password change logic
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         final currentPasswordController = TextEditingController();
//         final newPasswordController = TextEditingController();
//         final confirmPasswordController = TextEditingController();
//
//         return AlertDialog(
//           title: Text('Change Password'),
//           content: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               TextField(
//                 controller: currentPasswordController,
//                 decoration: InputDecoration(
//                   labelText: 'Current Password',
//                   border: OutlineInputBorder(),
//                 ),
//                 obscureText: true,
//               ),
//               SizedBox(height: 16),
//               TextField(
//                 controller: newPasswordController,
//                 decoration: InputDecoration(
//                   labelText: 'New Password',
//                   border: OutlineInputBorder(),
//                 ),
//                 obscureText: true,
//               ),
//               SizedBox(height: 16),
//               TextField(
//                 controller: confirmPasswordController,
//                 decoration: InputDecoration(
//                   labelText: 'Confirm New Password',
//                   border: OutlineInputBorder(),
//                 ),
//                 obscureText: true,
//               ),
//             ],
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: Text('Cancel'),
//             ),
//             ElevatedButton(
//               onPressed: () {
//                 // Validate and change password
//                 if (newPasswordController.text == confirmPasswordController.text) {
//                   _performPasswordChange(
//                     currentPasswordController.text,
//                     newPasswordController.text,
//                   );
//                   Navigator.of(context).pop();
//                 } else {
//                   ScaffoldMessenger.of(context).showSnackBar(
//                     SnackBar(
//                       content: Text('New passwords do not match'),
//                       backgroundColor: Colors.red,
//                     ),
//                   );
//                 }
//               },
//               child: Text('Change Password'),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   void _performPasswordChange(String currentPassword, String newPassword) async {
//     try {
//       final user = FirebaseAuth.instance.currentUser;
//       if (user == null) return;
//
//       // Re-authenticate user
//       final credential = EmailAuthProvider.credential(
//           email: user.email!,
//           password: currentPassword
//       );
//       await user.reauthenticateWithCredential(credential);
//
//       // Change password
//       await user.updatePassword(newPassword);
//
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(
//           content: Text('Password changed successfully'),
//           backgroundColor: Colors.green,
//         ),
//       );
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(
//           content: Text('Failed to change password: $e'),
//           backgroundColor: Colors.red,
//         ),
//       );
//     }
//   }
//
//   void _confirmAccountDeletion() {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return AlertDialog(
//           title: Text('Delete Account'),
//           content: Text(
//             'Are you sure you want to delete your account? '
//                 'This action cannot be undone and will permanently remove all your data.',
//           ),
//           actions: [
//             TextButton(
//               onPressed: () => Navigator.of(context).pop(),
//               child: Text('Cancel'),
//             ),
//             ElevatedButton(
//               style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
//               onPressed: _deleteAccount,
//               child: Text('Delete Account'),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   void _deleteAccount() async {
//     try {
//       final user = FirebaseAuth.instance.currentUser;
//       if (user == null) return;
//
//       // Delete user data from Firestore (optional)
//       await FirebaseFirestore.instance
//           .collection('users')
//           .doc(user.uid)
//           .delete();
//
//       // Delete user account
//       await user.delete();
//
//       // User will be automatically navigated to login screen
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(
//           content: Text('Account deleted successfully'),
//           backgroundColor: Colors.green,
//         ),
//       );
//     } catch (e) {
//       ScaffoldMessenger.of(context).showSnackBar(
//         SnackBar(
//           content: Text('Failed to delete account: $e'),
//           backgroundColor: Colors.red,
//         ),
//       );
//     }
//   }
// }