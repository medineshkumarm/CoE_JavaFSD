import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/coupon_model.dart';
import '../services/coupon_service.dart';
import 'coupon_detail_screen.dart';

class CouponListScreen extends StatelessWidget {
  const CouponListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Coupon Exchange'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () {
              // Navigate to coupon submission screen
              Navigator.pushNamed(context, '/submit-coupon');
            },
          ),
        ],
      ),
      body:




      StreamBuilder<List<Coupon>>(
        stream: context.watch<CouponService>().getCoupons(), // ✅ Auto UI Update
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error loading coupons'));
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          final coupons = snapshot.data ?? [];
          if (coupons.isEmpty) {
            return Center(child: Text('No coupons available'));
          }

          return ListView.builder(
            itemCount: coupons.length,
            itemBuilder: (context, index) {
              final coupon = coupons[index];
              return ListTile(
                title: Text(coupon.title),
                subtitle: Text(coupon.vendorName),
                trailing: Text('\$${coupon.discountValue.toStringAsFixed(2)}'),
                onTap: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CouponDetailScreen(coupon: coupon),
                    ),
                  );
                },
              );
            },
          );
        },
      ),

      // StreamBuilder<List<Coupon>>(
      //   stream: context.read<CouponService>().getCoupons(),
      //   builder: (context, snapshot) {
      //     if (snapshot.connectionState == ConnectionState.waiting) {
      //       return Center(child: CircularProgressIndicator());
      //     }
      //
      //     if (!snapshot.hasData || snapshot.data!.isEmpty) {
      //       return Center(child: Text('No coupons available'));
      //     }
      //
      //     return ListView.builder(
      //       itemCount: snapshot.data!.length,
      //       itemBuilder: (context, index) {
      //         final coupon = snapshot.data![index];
      //         return Dismissible(
      //           key: Key(coupon.id),
      //           background: Container(
      //             color: Colors.green,
      //             child: Icon(Icons.save, color: Colors.white),
      //           ),
      //           secondaryBackground: Container(
      //             color: Colors.red,
      //             child: Icon(Icons.delete, color: Colors.white),
      //           ),
      //           onDismissed: (direction) {
      //             if (direction == DismissDirection.endToStart) {
      //               // Optional: Implement delete logic
      //             }
      //           },
      //           child: ListTile(
      //             title: Text(coupon.title),
      //             subtitle: Text(coupon.vendorName),
      //             trailing: Text('\$${coupon.discountValue.toStringAsFixed(2)}'),
      //             onTap: () {
      //               Navigator.push(
      //                 context,
      //                 MaterialPageRoute(
      //                   builder: (context) => CouponDetailScreen(coupon: coupon),
      //                 ),
      //               );
      //             },
      //           ),
      //         );
      //       },
      //     );
      //   },
      // ),
    );
  }
}