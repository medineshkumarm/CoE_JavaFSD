import 'package:cloud_firestore/cloud_firestore.dart';

class Coupon {
  final String id;
  final String title;
  final String description;
  final String vendorName;
  final double discountValue;
  final DateTime expirationDate;
  final String userId;
  final bool isRedeemed;

  Coupon({
    required this.id,
    required this.title,
    required this.description,
    required this.vendorName,
    required this.discountValue,
    required this.expirationDate,
    required this.userId,
    this.isRedeemed = false,
  });

  factory Coupon.fromFirestore(DocumentSnapshot doc) {
    Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    return Coupon(
      id: doc.id,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      vendorName: data['vendorName'] ?? '',
      discountValue: (data['discountValue'] ?? 0.0).toDouble(),
      expirationDate: (data['expirationDate'] as Timestamp).toDate(),
      userId: data['userId'] ?? '',
      isRedeemed: data['isRedeemed'] ?? false,
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'title': title,
      'description': description,
      'vendorName': vendorName,
      'discountValue': discountValue,
      'expirationDate': expirationDate,
      'userId': userId,
      'isRedeemed': isRedeemed,
    };
  }
}