class AppConfig {
  // App-wide configuration constants
  static const String appName = 'Coupon Exchange';
  static const String appVersion = '1.0.0';

  // Firebase project configurations
  static const String firebaseProjectId = 'coupon-exchange-app';
  static const String firebaseApiKey = 'YOUR_FIREBASE_API_KEY';

  // Feature flags
  static const bool enableNotifications = true;
  static const bool enableAnalytics = true;

  // API endpoints (if applicable)
  static const String apiBaseUrl = 'https://api.couponexchange.com';

  // Supported languages
  static const List<String> supportedLanguages = [
    'en', // English
    'es', // Spanish
    'fr', // French
    'de', // German
    'zh', // Chinese
  ];

  // Theme configurations
  static const Map<String, dynamic> lightTheme = {
    'primaryColor': 0xFF2196F3,
    'accentColor': 0xFFFF4081,
    'backgroundColor': 0xFFFFFFFF,
  };

  static const Map<String, dynamic> darkTheme = {
    'primaryColor': 0xFF1976D2,
    'accentColor': 0xFFFF5252,
    'backgroundColor': 0xFF121212,
  };
}