import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/coupon_model.dart';

class CouponService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Fetch all active coupons
// Fetch all active coupons without orderBy
  Stream<List<Coupon>> getCoupons() {
    return _firestore
        .collection('coupons')
        .where('isRedeemed', isEqualTo: false)
        .snapshots()
        .map((snapshot) {
      final coupons = snapshot.docs.map((doc) => Coupon.fromFirestore(doc)).toList();
      print("🔥 Retrieved Coupons: ${coupons.length}"); // Debugging
      return coupons;
    });
  }

  // Submit a new coupon
  Future<void> submitCoupon(Coupon coupon) async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('User not authenticated');

    await _firestore.collection('coupons').add(
        coupon.toFirestore()
    );
  }

  // Redeem a coupon
  Future<void> redeemCoupon(String couponId) async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('User not authenticated');

    await _firestore.collection('coupons').doc(couponId).update({
      'isRedeemed': true,
    });
  }

  // Delete a coupon
  Future<void> deleteCoupon(String couponId) async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('User not authenticated');

    await _firestore.collection('coupons').doc(couponId).delete();
  }

  // Save a coupon
  Future<void> saveCoupon(String couponId) async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('User not authenticated');

    await _firestore.collection('coupons').doc(couponId).update({
      'isSaved': true,
    });
  }

  // Edit a coupon
  Future<void> editCoupon(String couponId, Map<String, dynamic> updatedData) async {
    final user = _auth.currentUser;
    if (user == null) throw Exception('User not authenticated');

    await _firestore.collection('coupons').doc(couponId).update(updatedData);
  }
}
